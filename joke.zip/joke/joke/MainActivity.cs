﻿using Android.App;
using Android.OS;
using Android.Runtime;
using AndroidX.AppCompat.App;
using Android.Widget;
using Android.Content;

namespace joke
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        TextView txtNomeGame, txtCriadores;
        ImageView imgLogo;
        Button btnOK;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_main);

            txtNomeGame = FindViewById<TextView>(Resource.Id.txtNomeGame);
            txtCriadores = FindViewById<TextView>(Resource.Id.txtCriadores);
            imgLogo = FindViewById<ImageView>(Resource.Id.imgLogo);
            btnOK = FindViewById<Button>(Resource.Id.btnOK);

            btnOK.Click += BtnOK_Click1;

        }

        private void BtnOK_Click1(object sender, System.EventArgs e)
        {
            Intent novaTela = new Intent(this, typeof(tela2));
            StartActivity(novaTela);
        }


        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}